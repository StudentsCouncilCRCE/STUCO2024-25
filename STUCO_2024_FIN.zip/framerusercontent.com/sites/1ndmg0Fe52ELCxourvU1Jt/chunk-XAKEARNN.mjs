function a(t,e){return{description:"Made with Framer",robots:"max-image-preview:large",title:"My Framer Site"}}export{a};
//# sourceMappingURL=chunk-XAKEARNN.mjs.map
